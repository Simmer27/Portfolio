﻿namespace assignment5
{
    partial class assignment5
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            gbStudentInfo = new GroupBox();
            cbGrade = new ComboBox();
            cbScore = new ComboBox();
            lblGrade = new Label();
            lblScore = new Label();
            lblEmail = new Label();
            txtEmail = new TextBox();
            txtSin = new TextBox();
            lblSin = new Label();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            lblLastName = new Label();
            lblFirstName = new Label();
            btnCheck = new Button();
            gbPrograms = new GroupBox();
            lblTotalCostNumber = new Label();
            lblStudyPeriodNumber = new Label();
            lblTotalCost = new Label();
            lblStudyPeriod = new Label();
            cbPrograms = new ComboBox();
            lblPrograms = new Label();
            cbLocation = new ComboBox();
            lblLocation = new Label();
            btnRegister = new Button();
            btnExit = new Button();
            btnRemove = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnLoad = new Button();
            lblSinSelect = new Label();
            cbSinSelect = new ComboBox();
            toolTip1 = new ToolTip(components);
            dgRecord = new DataGridView();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            registerToolStripMenuItem = new ToolStripMenuItem();
            recordToolStripMenuItem = new ToolStripMenuItem();
            updateRecordToolStripMenuItem = new ToolStripMenuItem();
            deleteRecordToolStripMenuItem = new ToolStripMenuItem();
            deleteAllRecordsToolStripMenuItem = new ToolStripMenuItem();
            loadRecordsToServerToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            readHelpToolStripMenuItem = new ToolStripMenuItem();
            technicalSupportsToolStripMenuItem = new ToolStripMenuItem();
            aboutDCRegistrationToolStripMenuItem = new ToolStripMenuItem();
            gbStudentInfo.SuspendLayout();
            gbPrograms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgRecord).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // gbStudentInfo
            // 
            gbStudentInfo.Controls.Add(cbGrade);
            gbStudentInfo.Controls.Add(cbScore);
            gbStudentInfo.Controls.Add(lblGrade);
            gbStudentInfo.Controls.Add(lblScore);
            gbStudentInfo.Controls.Add(lblEmail);
            gbStudentInfo.Controls.Add(txtEmail);
            gbStudentInfo.Controls.Add(txtSin);
            gbStudentInfo.Controls.Add(lblSin);
            gbStudentInfo.Controls.Add(txtLastName);
            gbStudentInfo.Controls.Add(txtFirstName);
            gbStudentInfo.Controls.Add(lblLastName);
            gbStudentInfo.Controls.Add(lblFirstName);
            gbStudentInfo.Location = new Point(12, 31);
            gbStudentInfo.Name = "gbStudentInfo";
            gbStudentInfo.Size = new Size(1032, 102);
            gbStudentInfo.TabIndex = 0;
            gbStudentInfo.TabStop = false;
            gbStudentInfo.Text = "Student Information";
            // 
            // cbGrade
            // 
            cbGrade.DropDownStyle = ComboBoxStyle.DropDownList;
            cbGrade.FormattingEnabled = true;
            cbGrade.Location = new Point(856, 69);
            cbGrade.Name = "cbGrade";
            cbGrade.Size = new Size(151, 28);
            cbGrade.TabIndex = 11;
            toolTip1.SetToolTip(cbGrade, "Select your highschool grade");
            cbGrade.SelectedIndexChanged += cbGrade_SelectedIndexChanged;
            // 
            // cbScore
            // 
            cbScore.DropDownStyle = ComboBoxStyle.DropDownList;
            cbScore.FormattingEnabled = true;
            cbScore.Location = new Point(856, 32);
            cbScore.Name = "cbScore";
            cbScore.Size = new Size(151, 28);
            cbScore.TabIndex = 10;
            toolTip1.SetToolTip(cbScore, "Select your admission test score");
            cbScore.SelectedIndexChanged += cbScore_SelectedIndexChanged;
            // 
            // lblGrade
            // 
            lblGrade.AutoSize = true;
            lblGrade.Location = new Point(716, 73);
            lblGrade.Name = "lblGrade";
            lblGrade.Size = new Size(134, 20);
            lblGrade.TabIndex = 9;
            lblGrade.Text = "High School Grade";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(701, 35);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(149, 20);
            lblScore.TabIndex = 8;
            lblScore.Text = "Admission Test Score";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(268, 73);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(46, 20);
            lblEmail.TabIndex = 7;
            lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(320, 70);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(357, 27);
            txtEmail.TabIndex = 6;
            toolTip1.SetToolTip(txtEmail, "Enter your email");
            // 
            // txtSin
            // 
            txtSin.Location = new Point(320, 32);
            txtSin.Name = "txtSin";
            txtSin.Size = new Size(357, 27);
            txtSin.TabIndex = 5;
            toolTip1.SetToolTip(txtSin, "Enter your SIN");
            // 
            // lblSin
            // 
            lblSin.AutoSize = true;
            lblSin.Location = new Point(282, 35);
            lblSin.Name = "lblSin";
            lblSin.Size = new Size(32, 20);
            lblSin.TabIndex = 4;
            lblSin.Text = "SIN";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(92, 70);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(155, 27);
            txtLastName.TabIndex = 3;
            toolTip1.SetToolTip(txtLastName, "Enter your last name");
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(92, 32);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(155, 27);
            txtFirstName.TabIndex = 2;
            toolTip1.SetToolTip(txtFirstName, "Enter your first name");
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(7, 73);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(79, 20);
            lblLastName.TabIndex = 1;
            lblLastName.Text = "Last Name";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(6, 39);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(80, 20);
            lblFirstName.TabIndex = 0;
            lblFirstName.Text = "First Name";
            // 
            // btnCheck
            // 
            btnCheck.Location = new Point(12, 139);
            btnCheck.Name = "btnCheck";
            btnCheck.Size = new Size(142, 38);
            btnCheck.TabIndex = 1;
            btnCheck.Text = "&Check";
            toolTip1.SetToolTip(btnCheck, "Click to check");
            btnCheck.UseVisualStyleBackColor = true;
            btnCheck.Click += btnCheck_Click;
            // 
            // gbPrograms
            // 
            gbPrograms.Controls.Add(lblTotalCostNumber);
            gbPrograms.Controls.Add(lblStudyPeriodNumber);
            gbPrograms.Controls.Add(lblTotalCost);
            gbPrograms.Controls.Add(lblStudyPeriod);
            gbPrograms.Controls.Add(cbPrograms);
            gbPrograms.Controls.Add(lblPrograms);
            gbPrograms.Controls.Add(cbLocation);
            gbPrograms.Controls.Add(lblLocation);
            gbPrograms.Location = new Point(12, 183);
            gbPrograms.Name = "gbPrograms";
            gbPrograms.Size = new Size(1032, 93);
            gbPrograms.TabIndex = 2;
            gbPrograms.TabStop = false;
            gbPrograms.Text = "Available Programs";
            // 
            // lblTotalCostNumber
            // 
            lblTotalCostNumber.AutoSize = true;
            lblTotalCostNumber.Location = new Point(939, 58);
            lblTotalCostNumber.Name = "lblTotalCostNumber";
            lblTotalCostNumber.Size = new Size(36, 20);
            lblTotalCostNumber.TabIndex = 7;
            lblTotalCostNumber.Text = "0.0$";
            // 
            // lblStudyPeriodNumber
            // 
            lblStudyPeriodNumber.AutoSize = true;
            lblStudyPeriodNumber.Location = new Point(845, 58);
            lblStudyPeriodNumber.Name = "lblStudyPeriodNumber";
            lblStudyPeriodNumber.Size = new Size(17, 20);
            lblStudyPeriodNumber.TabIndex = 6;
            lblStudyPeriodNumber.Text = "0";
            // 
            // lblTotalCost
            // 
            lblTotalCost.AutoSize = true;
            lblTotalCost.Location = new Point(923, 32);
            lblTotalCost.Name = "lblTotalCost";
            lblTotalCost.Size = new Size(75, 20);
            lblTotalCost.TabIndex = 5;
            lblTotalCost.Text = "Total Cost";
            // 
            // lblStudyPeriod
            // 
            lblStudyPeriod.AutoSize = true;
            lblStudyPeriod.Location = new Point(809, 32);
            lblStudyPeriod.Name = "lblStudyPeriod";
            lblStudyPeriod.Size = new Size(92, 20);
            lblStudyPeriod.TabIndex = 4;
            lblStudyPeriod.Text = "Study Period";
            // 
            // cbPrograms
            // 
            cbPrograms.DropDownStyle = ComboBoxStyle.DropDownList;
            cbPrograms.FormattingEnabled = true;
            cbPrograms.Location = new Point(487, 29);
            cbPrograms.Name = "cbPrograms";
            cbPrograms.Size = new Size(245, 28);
            cbPrograms.TabIndex = 3;
            toolTip1.SetToolTip(cbPrograms, "Select a program");
            // 
            // lblPrograms
            // 
            lblPrograms.AutoSize = true;
            lblPrograms.Location = new Point(409, 32);
            lblPrograms.Name = "lblPrograms";
            lblPrograms.Size = new Size(72, 20);
            lblPrograms.TabIndex = 2;
            lblPrograms.Text = "Programs";
            // 
            // cbLocation
            // 
            cbLocation.DropDownStyle = ComboBoxStyle.DropDownList;
            cbLocation.FormattingEnabled = true;
            cbLocation.Location = new Point(148, 29);
            cbLocation.Name = "cbLocation";
            cbLocation.Size = new Size(233, 28);
            cbLocation.TabIndex = 1;
            toolTip1.SetToolTip(cbLocation, "Select a campus location");
            // 
            // lblLocation
            // 
            lblLocation.AutoSize = true;
            lblLocation.Location = new Point(19, 32);
            lblLocation.Name = "lblLocation";
            lblLocation.Size = new Size(123, 20);
            lblLocation.TabIndex = 0;
            lblLocation.Text = "Campus Location";
            // 
            // btnRegister
            // 
            btnRegister.Location = new Point(12, 282);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(142, 40);
            btnRegister.TabIndex = 3;
            btnRegister.Text = "&Register Student";
            toolTip1.SetToolTip(btnRegister, "Click to register student");
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(898, 575);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 34);
            btnExit.TabIndex = 9;
            btnExit.Text = "E&xit";
            toolTip1.SetToolTip(btnExit, "Click to exit application");
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(460, 523);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(204, 34);
            btnRemove.TabIndex = 6;
            btnRemove.Text = "Remo&ve All Records";
            toolTip1.SetToolTip(btnRemove, "Click to remove all records");
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(31, 525);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(152, 34);
            btnDelete.TabIndex = 4;
            btnDelete.Text = "&Delete Record";
            toolTip1.SetToolTip(btnDelete, "Click to delete record");
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(189, 525);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(160, 32);
            btnUpdate.TabIndex = 5;
            btnUpdate.Text = "&Update Record";
            toolTip1.SetToolTip(btnUpdate, "Click to update record");
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(680, 523);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(194, 34);
            btnLoad.TabIndex = 7;
            btnLoad.Text = "&Load Records to Server";
            toolTip1.SetToolTip(btnLoad, "Click to load records to the server");
            btnLoad.UseVisualStyleBackColor = true;
            // 
            // lblSinSelect
            // 
            lblSinSelect.AutoSize = true;
            lblSinSelect.Location = new Point(31, 584);
            lblSinSelect.Name = "lblSinSelect";
            lblSinSelect.Size = new Size(32, 20);
            lblSinSelect.TabIndex = 9;
            lblSinSelect.Text = "SIN";
            // 
            // cbSinSelect
            // 
            cbSinSelect.DropDownStyle = ComboBoxStyle.DropDownList;
            cbSinSelect.FormattingEnabled = true;
            cbSinSelect.Location = new Point(69, 581);
            cbSinSelect.Name = "cbSinSelect";
            cbSinSelect.Size = new Size(280, 28);
            cbSinSelect.TabIndex = 8;
            toolTip1.SetToolTip(cbSinSelect, "Select a SIN");
            // 
            // dgRecord
            // 
            dgRecord.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgRecord.Location = new Point(12, 328);
            dgRecord.Name = "dgRecord";
            dgRecord.RowHeadersWidth = 51;
            dgRecord.RowTemplate.Height = 29;
            dgRecord.Size = new Size(1032, 188);
            dgRecord.TabIndex = 10;
            dgRecord.SelectionChanged += dgRecord_SelectionChanged;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1056, 28);
            menuStrip1.TabIndex = 11;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registerToolStripMenuItem, recordToolStripMenuItem, deleteAllRecordsToolStripMenuItem, loadRecordsToServerToolStripMenuItem, toolStripSeparator1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(46, 24);
            fileToolStripMenuItem.Text = "File";
            // 
            // registerToolStripMenuItem
            // 
            registerToolStripMenuItem.Name = "registerToolStripMenuItem";
            registerToolStripMenuItem.Size = new Size(245, 26);
            registerToolStripMenuItem.Text = "Register";
            // 
            // recordToolStripMenuItem
            // 
            recordToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { updateRecordToolStripMenuItem, deleteRecordToolStripMenuItem });
            recordToolStripMenuItem.Name = "recordToolStripMenuItem";
            recordToolStripMenuItem.Size = new Size(245, 26);
            recordToolStripMenuItem.Text = "Record";
            // 
            // updateRecordToolStripMenuItem
            // 
            updateRecordToolStripMenuItem.Name = "updateRecordToolStripMenuItem";
            updateRecordToolStripMenuItem.Size = new Size(192, 26);
            updateRecordToolStripMenuItem.Text = "Update Record";
            // 
            // deleteRecordToolStripMenuItem
            // 
            deleteRecordToolStripMenuItem.Name = "deleteRecordToolStripMenuItem";
            deleteRecordToolStripMenuItem.Size = new Size(192, 26);
            deleteRecordToolStripMenuItem.Text = "Delete Record";
            // 
            // deleteAllRecordsToolStripMenuItem
            // 
            deleteAllRecordsToolStripMenuItem.Name = "deleteAllRecordsToolStripMenuItem";
            deleteAllRecordsToolStripMenuItem.Size = new Size(245, 26);
            deleteAllRecordsToolStripMenuItem.Text = "Delete all Records";
            // 
            // loadRecordsToServerToolStripMenuItem
            // 
            loadRecordsToServerToolStripMenuItem.Name = "loadRecordsToServerToolStripMenuItem";
            loadRecordsToServerToolStripMenuItem.Size = new Size(245, 26);
            loadRecordsToServerToolStripMenuItem.Text = "Load Records to Server";
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(242, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(245, 26);
            exitToolStripMenuItem.Text = "Exit";
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { readHelpToolStripMenuItem, technicalSupportsToolStripMenuItem, aboutDCRegistrationToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(55, 24);
            helpToolStripMenuItem.Text = "Help";
            // 
            // readHelpToolStripMenuItem
            // 
            readHelpToolStripMenuItem.Name = "readHelpToolStripMenuItem";
            readHelpToolStripMenuItem.Size = new Size(275, 26);
            readHelpToolStripMenuItem.Text = "Read Help";
            // 
            // technicalSupportsToolStripMenuItem
            // 
            technicalSupportsToolStripMenuItem.Name = "technicalSupportsToolStripMenuItem";
            technicalSupportsToolStripMenuItem.Size = new Size(275, 26);
            technicalSupportsToolStripMenuItem.Text = "Technical Supports";
            // 
            // aboutDCRegistrationToolStripMenuItem
            // 
            aboutDCRegistrationToolStripMenuItem.Name = "aboutDCRegistrationToolStripMenuItem";
            aboutDCRegistrationToolStripMenuItem.Size = new Size(275, 26);
            aboutDCRegistrationToolStripMenuItem.Text = "About DC-Registration App";
            // 
            // assignment5
            // 
            AcceptButton = btnUpdate;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = btnExit;
            ClientSize = new Size(1056, 636);
            Controls.Add(dgRecord);
            Controls.Add(cbSinSelect);
            Controls.Add(lblSinSelect);
            Controls.Add(btnLoad);
            Controls.Add(btnUpdate);
            Controls.Add(btnDelete);
            Controls.Add(btnRemove);
            Controls.Add(btnExit);
            Controls.Add(btnRegister);
            Controls.Add(gbPrograms);
            Controls.Add(btnCheck);
            Controls.Add(gbStudentInfo);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MaximizeBox = false;
            MaximumSize = new Size(1074, 683);
            MinimizeBox = false;
            MinimumSize = new Size(1074, 683);
            Name = "assignment5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DC Registration App";
            gbStudentInfo.ResumeLayout(false);
            gbStudentInfo.PerformLayout();
            gbPrograms.ResumeLayout(false);
            gbPrograms.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgRecord).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox gbStudentInfo;
        private Label lblFirstName;
        private Label lblGrade;
        private Label lblScore;
        private Label lblEmail;
        private TextBox txtEmail;
        private TextBox txtSin;
        private Label lblSin;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private Label lblLastName;
        private ComboBox cbGrade;
        private ComboBox cbScore;
        private Button btnCheck;
        private GroupBox gbPrograms;
        private Label lblTotalCostNumber;
        private Label lblStudyPeriodNumber;
        private Label lblTotalCost;
        private Label lblStudyPeriod;
        private ComboBox cbPrograms;
        private Label lblPrograms;
        private ComboBox cbLocation;
        private Label lblLocation;
        private Button btnRegister;
        private Button btnExit;
        private Button btnRemove;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnLoad;
        private Label lblSinSelect;
        private ComboBox cbSinSelect;
        private ToolTip toolTip1;
        private DataGridView dgRecord;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem registerToolStripMenuItem;
        private ToolStripMenuItem recordToolStripMenuItem;
        private ToolStripMenuItem updateRecordToolStripMenuItem;
        private ToolStripMenuItem deleteRecordToolStripMenuItem;
        private ToolStripMenuItem deleteAllRecordsToolStripMenuItem;
        private ToolStripMenuItem loadRecordsToServerToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem readHelpToolStripMenuItem;
        private ToolStripMenuItem technicalSupportsToolStripMenuItem;
        private ToolStripMenuItem aboutDCRegistrationToolStripMenuItem;
    }
}