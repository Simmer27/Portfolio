﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment5
{
    public class campus
    {
        // Properties.
        public int HSGradeReq { get; set; } // Admission requirement: High school grade.
        public int AdmissionTSReq { get; set; } // Admission requirement: Admission test score.
        public int RegFees { get; set; } // Registration fees.
        public List<schoolProgram> ListPrograms { get; set; } // List of available programs.

        // Name property for Campus.
        public string Name { get; set; }

        // Constructor.
        public campus(string name, int hsGradeReq, int admissionTSReq, int regFees, List<schoolProgram> programs)
        {
            Name = name;
            HSGradeReq = hsGradeReq;
            AdmissionTSReq = admissionTSReq;
            RegFees = regFees;
            ListPrograms = programs;
        }
        
    }

    public class schoolProgram
    {
        // Properties.
        public string ProgramName { get; set; }
        public int ProgramFees { get; set; }
        public int ProgramDuration { get; set; }

        // Constructor.
        public schoolProgram(string programName, int programFees, int programDuration)
        {
            ProgramName = programName;
            ProgramFees = programFees;
            ProgramDuration = programDuration;
        }


    }

}

