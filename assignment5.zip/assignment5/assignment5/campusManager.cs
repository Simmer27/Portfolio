﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment5
{
    public class campusManager
    {
        public campus GetSelectedCampus(List<campus> campusesList, string selectedCampusName)
        {
            return campusesList.Find(campus => campus.Name == selectedCampusName);
        }
    }
}
