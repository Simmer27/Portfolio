// Name: Matthew Simpson
// Application: Assignment 5
// Date:2023/12/04
// Description: This application will take a students input of their name, email, SIN, Test score and highschool grade.
// As well as their program and campus location. The application will be able to calculate the tution cost and study period.
// The students information can be uploaded to the admissions database.


namespace assignment5
{
    public partial class assignment5 : Form
    {
        private List<campus> campusesList;
        private List<student> studentsList;
        public assignment5()
        {
            InitializeComponent();
            Dictionary<string, List<schoolProgram>> campusPrograms = new Dictionary<string, List<schoolProgram>>
            {
                {
                    "Ontario", new List<schoolProgram>
                    {
                        new schoolProgram("Architectural", 8000, 4),
                        new schoolProgram("Science and Art", 7000, 5),
                        new schoolProgram("Engineering", 8500, 4),
                        new schoolProgram("Business", 7500, 5)
                       
                    }
                },
                {
                    "Quebec", new List<schoolProgram>
                    {
                        new schoolProgram("Law", 9000, 4),
                        new schoolProgram("Health", 8500, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Engineering", 8200, 5)
                      
                    }
                },
                {
                    "Nova Scotia", new List<schoolProgram>
                    {
                        new schoolProgram("Engineering", 7800, 4),
                        new schoolProgram("Business", 7200, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Architectural", 8000, 5)
                      
                    }
                },
                {
                    "New Brunswick", new List<schoolProgram>
                    {
                        new schoolProgram("Architectural", 8000, 4),
                        new schoolProgram("Science and Art", 7000, 5),
                        new schoolProgram("Engineering", 8500, 4),
                        new schoolProgram("Business", 7500, 5)
                     
                    }
                },
                {
                    "Manitoba", new List<schoolProgram>
                    {
                        new schoolProgram("Law", 9000, 4),
                        new schoolProgram("Health", 8500, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Engineering", 8200, 5)
                       
                    }
                },
                {
                    "British Columbia", new List<schoolProgram>
                    {
                        new schoolProgram("Engineering", 7800, 4),
                        new schoolProgram("Business", 7200, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Architectural", 8000, 5)
                     
                    }
                },
                {
                    "Prince Edward Island", new List<schoolProgram>
                    {
                        new schoolProgram("Architectural", 8000, 4),
                        new schoolProgram("Science and Art", 7000, 5),
                        new schoolProgram("Engineering", 8500, 4),
                        new schoolProgram("Business", 7500, 5)
                     
                    }
                },
                {
                    "Saskatchewan", new List<schoolProgram>
                    {
                        new schoolProgram("Law", 9000, 4),
                        new schoolProgram("Health", 8500, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Engineering", 8200, 5)
                        
                    }
                },
                {
                    "Alberta", new List<schoolProgram>
                    {
                        new schoolProgram("Engineering", 7800, 4),
                        new schoolProgram("Business", 7200, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Architectural", 8000, 5)
                      
                    }
                },
                {
                    "Newfoundland and Labrador", new List<schoolProgram>
                    {
                        new schoolProgram("Engineering", 7800, 4),
                        new schoolProgram("Business", 7200, 5),
                        new schoolProgram("Science and Art", 7500, 4),
                        new schoolProgram("Architectural", 8000, 5)
                        
                    }
                },
            };

            PopulateCampusDropdown();
            InitializeFormData();
            studentsList = new List<student>();
        }

        private void InitializeFormData()
        {
            string[] campusLocations = { "Ontario", "Quebec", "Nova Scotia", "New Brunswick", "Manitoba", "British Columbia", "Prince Edward Island", "Saskatchewan", "Alberta", "Newfoundland and Labrador" };
            cbLocation.Items.AddRange(campusLocations);

            cbLocation.SelectedIndexChanged += cbLocation_SelectedIndexChanged;

            for (int i = 0; i <= 100; i++)
            {
                cbScore.Items.Add(i);
            }

            for (int grade = 0; grade <= 100; grade++)
            {
                cbGrade.Items.Add(grade);
            }


            Dictionary<string, string[]> programsByLocation = new Dictionary<string, string[]>
            {
                { "Ontario", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Quebec", new string[] { "Science and Art", "Law", "Health" } },
                { "Nova Scotia", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "New Brunswick", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Manitoba", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "British Columbia", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Prince Edward Island", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Saskatchewan", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Alberta", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } },
                { "Newfoundland and Labrador", new string[] { "Architectural", "Science and Art", "Engineering", "Business" } }
            };


            cbLocation.SelectedIndexChanged += (sender, args) =>
            {
                cbPrograms.Items.Clear();
                string selectedLocation = cbLocation.SelectedItem?.ToString();
                if (selectedLocation != null && programsByLocation.ContainsKey(selectedLocation))
                {
                    cbPrograms.Items.AddRange(programsByLocation[selectedLocation]);
                }
            };

        }

        private void PopulateCampusDropdown()
        {
            cbLocation.Items.Clear();
            if (campusesList != null && campusesList.Any())
            {
                foreach (var campus in campusesList)
                {
                    cbLocation.Items.Add(campus.Name);
                }
            }
            else
            {
                
            }
        }

        private void cbLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        private void ActivateProgramDropdowns(campus selectedCampus)
        {
            cbPrograms.Items.Clear();

            if (selectedCampus != null)
            {
                // Check if the selected campus has programs.
                if (selectedCampus.ListPrograms != null && selectedCampus.ListPrograms.Any())
                {
                    foreach (var program in selectedCampus.ListPrograms)
                    {
                        cbPrograms.Items.Add(program.ProgramName);
                    }

                    cbPrograms.Enabled = true;

                 
                    cbPrograms.SelectedIndexChanged += (sender, e) =>
                    {
                        string selectedProgram = cbPrograms.SelectedItem.ToString();

                       
                        var selectedProgramDetails = selectedCampus.ListPrograms.FirstOrDefault(p => p.ProgramName == selectedProgram);

                        if (selectedProgramDetails != null)
                        {
                           
                            Random random = new Random();
                            int studyPeriod = random.Next(1, 5);
                            decimal cost = random.Next(5000, 10001);

                            lblStudyPeriodNumber.Text = $"Study Period for {selectedProgram}: {studyPeriod} years";
                            lblTotalCostNumber.Text = $"Cost for {selectedProgram}: ${cost}";
                        }
                    };
                }
                else
                {
                    MessageBox.Show("No programs available for the selected campus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ResetProgramDropdowns();
                }
            }
            else
            {
                MessageBox.Show("Invalid campus selection.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ResetProgramDropdowns(); 
            }
        }

        private void ResetProgramDropdowns()
        {
            cbPrograms.Items.Clear();
            cbPrograms.Enabled = false;
        }


        // Handle click event for the Check button.
        private void btnCheck_Click(object sender, EventArgs e)
        {
            
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string sin = txtSin.Text;
            string email = txtEmail.Text;
            int admissionTestScore = Convert.ToInt32(cbScore.SelectedItem);
            int highSchoolGrade = Convert.ToInt32(cbGrade.SelectedItem);

       
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(sin) ||
                string.IsNullOrWhiteSpace(email) || cbScore.SelectedIndex == -1 || cbGrade.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the selected campus from ComboBox.
            if (cbLocation.SelectedItem != null)
            {
                string selectedCampusName = cbLocation.SelectedItem.ToString();

               
                campus selectedCampus = campusesList.Find(c => c.Name == selectedCampusName);

                if (selectedCampus != null)
                {
                    if (highSchoolGrade >= selectedCampus.HSGradeReq && admissionTestScore >= selectedCampus.AdmissionTSReq)
                    {
                       
                        ActivateProgramDropdowns(selectedCampus);
                    }
                    else
                    {
                        MessageBox.Show("Student does not meet the admission criteria.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        ResetProgramDropdowns();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid campus selection.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a campus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Handle click event for the Register button.
        private void btnRegister_Click(object sender, EventArgs e)
        {
       
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string sin = txtSin.Text;
            string email = txtEmail.Text;
            int admissionTestScore = Convert.ToInt32(cbScore.SelectedItem);
            int highSchoolGrade = Convert.ToInt32(cbGrade.SelectedItem);
            string campusLocation = cbLocation.SelectedItem.ToString(); 
            string programName = cbPrograms.SelectedItem.ToString();

          
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(sin) ||
                string.IsNullOrWhiteSpace(email) || cbScore.SelectedIndex == -1 || cbGrade.SelectedIndex == -1 || cbPrograms.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

           
            if (IsStudentRegistered(sin))
            {
                MessageBox.Show("The student is already registered.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

          
            student newStudent = new student(firstName, lastName, int.Parse(sin), email, highSchoolGrade, admissionTestScore, campusLocation, programName);

            
            studentsList.Add(newStudent);

          
            UpdateDataGridView(); 
            MessageBox.Show("Student registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        // Method to check if the student is already registered.
        private bool IsStudentRegistered(string sin)
        {
            return studentsList.Exists(student => student.SIN == int.Parse(sin));
        }



        // Handle click event for the Update Record button.
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string selectedSIN = cbSinSelect.SelectedItem?.ToString(); 

            if (!string.IsNullOrEmpty(selectedSIN))
            {
                
                student selectedStudent = studentsList.Find(student => student.SIN == int.Parse(selectedSIN));

                if (selectedStudent != null)
                {
                   
                    string firstName = txtFirstName.Text;
                    string lastName = txtLastName.Text;
                    string sin = txtSin.Text;
                    string email = txtEmail.Text;
                    int admissionTestScore = Convert.ToInt32(cbScore.SelectedItem);
                    int highSchoolGrade = Convert.ToInt32(cbGrade.SelectedItem);

              
                    selectedStudent.FirstName = firstName;
                    selectedStudent.LastName = lastName;
                    selectedStudent.SIN = int.Parse(sin);
                    selectedStudent.Email = email;
                    selectedStudent.AdmissionTestScore = admissionTestScore;
                    selectedStudent.HighSchoolGrade = highSchoolGrade;

           
                    UpdateDataGridView();

                    MessageBox.Show("Student information updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Student not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a student to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Handle click event for the Delete Record button.
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string selectedSIN = cbSinSelect.SelectedItem?.ToString(); 

            if (!string.IsNullOrEmpty(selectedSIN))
            {
              
                int indexToRemove = studentsList.FindIndex(student => student.SIN == int.Parse(selectedSIN));

                if (indexToRemove != -1)
                {
                  
                    studentsList.RemoveAt(indexToRemove);

             
                    UpdateDataGridView();

                    MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Student not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a student to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Handle click event for the Remove all Records button.
        private void btnRemove_Click(object sender, EventArgs e)
        {

            dgRecord.Rows.Clear();

            studentsList.Clear();

        
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtSin.Text = string.Empty;
            txtEmail.Text = string.Empty;
            cbScore.SelectedIndex = -1;
            cbGrade.SelectedIndex = -1;
           
        }

        // Function to update the database grid.
        private void UpdateDataGridView()
        {
            dgRecord.Rows.Clear(); 

            foreach (var student in studentsList)
            {
                dgRecord.Rows.Add(new object[] { student.FirstName, student.LastName, student.SIN });
            }
        }


        // Event handler for DataGridView row selection.
        private void dgRecord_SelectionChanged(object sender, EventArgs e)
        {
            if (dgRecord.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgRecord.SelectedRows[0];

                txtFirstName.Text = selectedRow.Cells[0].Value.ToString();
                txtLastName.Text = selectedRow.Cells[1].Value.ToString();
                txtSin.Text = selectedRow.Cells[2].Value.ToString();

            }
        }

        // Event handler for the admission test score ComboBox.
        private void cbScore_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (int.TryParse(cbScore.SelectedItem?.ToString(), out int selectedScore))
            {
                if (selectedScore >= 80)
                {
                    MessageBox.Show("High score! Excellent performance.", "Score Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (selectedScore >= 60)
                {
                    MessageBox.Show("Good score! Keep up the good work.", "Score Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Your score is below the expected range.", "Score Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid score.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for the high school grade ComboBox.
        private void cbGrade_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (int.TryParse(cbGrade.SelectedItem?.ToString(), out int selectedGrade))
            {
                if (selectedGrade >= 80)
                {
                    MessageBox.Show("Excellent high school grade!", "Grade Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (selectedGrade >= 60)
                {
                    MessageBox.Show("Good high school grade! Keep it up.", "Grade Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Your high school grade might need improvement.", "Grade Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid grade.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler to close application when the exit button is clicked.
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

